@if(count($dataClassRecord['getRecord']) !== 0)
<div>
    
</div>
<div class="table-responsive w-100 pb-3">
    

</div>
@else
<div class="d-flex bg-warning text-white">
    The class has no data. 
</div>
@endif


