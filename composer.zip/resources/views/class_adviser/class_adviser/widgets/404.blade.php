<div class="d-flex row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body text-center d-flex flex-col justify-content-center align-items-center">
                <img src="{{ asset('dist/images/backgrounds/website-under-construction.gif') }}" alt="" class="img-fluid mb-4"
                    width="200">
                <h5 class="fw-semibold fs-5 mb-2">Oops something went wrong!</h5>
                <p class="mb-3 px-xl-5">You are not permitted. Retry or contact the admin</p>
            </div>
        </div>
    </div>
</div>
