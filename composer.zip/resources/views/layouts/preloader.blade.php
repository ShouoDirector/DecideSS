<!-- Preloader -->
<div class="preloader">
    <img src="{{ asset('favicon.ico') }}"
        alt="loader" class="lds-ripple img-fluid" />
</div>
<!-- Preloader -->
<div class="preloader">
    <img src="{{ asset('favicon.ico') }}"
        alt="loader" class="lds-ripple img-fluid" />
</div>
